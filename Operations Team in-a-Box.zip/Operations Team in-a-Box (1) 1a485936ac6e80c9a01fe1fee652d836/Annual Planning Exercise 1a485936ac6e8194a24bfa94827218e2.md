# Annual Planning Exercise

[Planning Calendar](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Planning%20Calendar%201a485936ac6e81d7b226d81ca4e25a6e.csv)

- The calendar of events:
    - **Inputs:** learnings, reflections, etc.
    - **Goals:** what results will indicate success?
    - **Roadmaps:** what work will help us hit goals?

[Planning Deliverables](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Planning%20Deliverables%201a485936ac6e81a2a8d2e975c23b1212.csv)

- The outputs and results of planning, resulting in our teams’ **objectives** and **operational plans**

[](OKR%20Tracker%201a485936ac6e8130956fdfdeda7b56b5.md) 

- Our company-wide objectives that we’ll track
- Once these are finalized, we’ll continually revisit these in business reviews, etc.

[Company Initiatives](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d.csv)

- The strategic initiatives and projects teams will take on over the next half in order to hit our OKRs
- All teams will contribute to these projects via their H1 plans

<aside>
<img src="https://www.notion.so/icons/bullseye_green.svg" alt="https://www.notion.so/icons/bullseye_green.svg" width="40px" /> **Goal:** help your entire team, organization, or company plan effectively to hit your hardest goals.

1. Start by laying out your [](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Planning%20Calendar%201a485936ac6e81d7b226d81ca4e25a6e.md) to get everyone aligned on the who, what, and where for planning
2. Use [](OKR%20Tracker%201a485936ac6e8130956fdfdeda7b56b5.md) to outline your priorities for the half that will be shared with teams; you can use a [mid-term strategy doc](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Planning%20Deliverables%201a485936ac6e81a2a8d2e975c23b1212/Notion%20Mid-Term%20Strategy%201a485936ac6e810ba7ffd7215ac7336a.md) to describe why these are your priorities
3. Individual teams then fill out a [H1 Team Plan Template](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Planning%20Deliverables%201a485936ac6e81a2a8d2e975c23b1212/H1%20Team%20Plan%20Template%201a485936ac6e81c8a943ffd17fd24e8c.md), reflecting on what they want to achieve and how their work ladders up to objectives
4. This template makes use of a [](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d.md) database to consolidate what teams are working on for easy review and connects this to company objectives
</aside>

## Planning Calendar

[Untitled](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Untitled%201a485936ac6e8163a61df6dcd130f3e8.csv)

## Planning Deliverables

[Untitled](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Untitled%201a485936ac6e81b4a116de483c961721.csv)

[Teams](Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Teams%201a485936ac6e81838e99c43b6f2a8574.csv)