# Advanced inventory tracking

Status: Planning
Priority: Medium
Owner: Holly Avery
Dates: June 24, 2023 → July 24, 2023
Blocked By: Order fulfillment optimization (Order%20fulfillment%20optimization%201a485936ac6e81688e4dc6117d02a5c0.md)

| **Driver(s)** |  |
| --- | --- |
| **Approver(s)** |  |
| **Contributors** |  |
| **Informed** |  |
| Product spec |  |

### Summary

<aside>
<img src="https://www.notion.so/icons/info-alternate_gray.svg" alt="https://www.notion.so/icons/info-alternate_gray.svg" width="40px" />

</aside>

# Background

What is the status quo and why are we doing this?

## Context

*Give a quick 1-2 line summary of the project to orient your readers.*

## Goals & Key Performance Indicators

*What are you hoping to achieve with this project? How will you know once you've gotten there?*

| Metric | Target |
| --- | --- |
|  |  |
|  |  |

## Constraints

*What limitations will you need to consider when building this product?*

## Assumptions

*What assumptions are you making about your audience?*

# Processes & Flows

Add any relevant flow diagrams and sketches.

[https://miro.com/app/board/uXjVM-chCUk=/?share_link_id=977546363789](https://miro.com/app/board/uXjVM-chCUk=/?share_link_id=977546363789)

# Requirements

Explicit functional and non-functional requirements required pre-approval.

- [ ]  
- [ ]  
- [ ]  

## Dependencies

*In order to do this project, what else must be true? What does this project rely on?*

## Risks

| Risk | Risk Level | Mitigating Action | Contingent Action |
| --- | --- | --- | --- |
|  | `LOW` `MED` `HIGH` |  |  |
|  |  |  |  |
|  |  |  |  |

## Performance dashboards