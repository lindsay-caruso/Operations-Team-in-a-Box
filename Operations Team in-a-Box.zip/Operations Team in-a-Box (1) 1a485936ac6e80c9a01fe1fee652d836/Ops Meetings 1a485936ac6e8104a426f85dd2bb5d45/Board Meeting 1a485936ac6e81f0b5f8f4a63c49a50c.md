# Board Meeting

Recurring: Yes
Type: Board Meeting

<aside>
💡 Pre-fill this template so as to act as your agenda for your next board meeting.
Take any additional notes at the bottom of the page.

</aside>

# Progress Updates

Summary of announcements for your board.

- 
- 
- 

## Metrics Dashboard Review

Embed or link to your live dashboards like Tableau or Hex.

### KPIs

[https://www.notion.so](https://www.notion.so)

### Financials

[https://www.notion.so](https://www.notion.so)

# Topics to discuss

Strategic discussions, problem-solving, complex decision making all happen here. Populate this before your board meeting. You can share this page for them to add their discussion points.

- Topic#1
    - Problem:
        - Option 1:
        - Option 2:
        - Option 3:
- Topic #2

# Other actions

Any decision that requires approval or a vote from the board.

| Subject | Type |
| --- | --- |
|  | To be approved |
|  | For vote |
|  |  |

---

# Notes

- 

# Follow-up Actions

List all actions to be taken and their owner.

-