# Team Weekly

Lead: Drew Evans
Meeting Date: January 24, 2023
Recurring: Yes

### 20th September

### **📣 Agenda**

- Access to website analytics dashboard?
- Onboarding bottleneck. Do we need to outsource?

### 🗒️ **Notes**

- New benefits employee dashboard launch
    - Launch date pushed to November 3, 2022

### **☑️ Action Items**

- [x]  Presentation for townhall
    - [x]  Put trial run on the calendar - @MP

### 13th September

### **📣 Agenda**

- New joiner, Frederick. First day on Monday!
- Results from newsletter feature experiment

### 🗒️ **Notes**

- Experiment successful! Identify top 5 engineering publications and newsletter to feature in

### **☑️ Action Items**

- [x]  Budget approval for paid promotion by June 10, 2023 9:00 AM (GMT+3)