# Marketing

Initiatives: Tech Alliance Network (../Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Tech%20Alliance%20Network%201a485936ac6e812e9a87f0b1cb4c76d4.md)
Lead: Virginia Conde
Related OKR: Enter emerging markets (../../OKR%20Tracker%201a485936ac6e8130956fdfdeda7b56b5/Enter%20emerging%20markets%201a485936ac6e81e8b155e26de354116a.md)