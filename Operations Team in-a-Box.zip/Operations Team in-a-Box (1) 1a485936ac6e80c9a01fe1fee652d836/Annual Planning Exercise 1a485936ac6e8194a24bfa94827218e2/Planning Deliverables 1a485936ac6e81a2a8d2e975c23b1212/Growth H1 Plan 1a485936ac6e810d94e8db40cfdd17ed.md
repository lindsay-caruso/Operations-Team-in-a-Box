# Growth H1 Plan

Type: Team Plan
Owner: Daniel Pyykonen
Status: In progress
👥 Team: Growth (../Teams%201a485936ac6e81838e99c43b6f2a8574/Growth%201a485936ac6e8132a716f70c27841075.md)

## 1️⃣ Learnings from 2022

<aside>
🧠 What did your team learn in H1 that will inform your plans for this half?

</aside>

- 

## 2️⃣ Strategy for 2023

<aside>
🥅 What is your teams’ high-level strategy for this half? How does it relate to ‣?

</aside>

- 

## 3️⃣ Team Goals

<aside>
📈 How will your team measure success in H1? How do these goals relate to [](../../OKR%20Tracker%201a485936ac6e8130956fdfdeda7b56b5.md)?

</aside>

- 

## 4️⃣ Major Initiatives

<aside>
🏋️ What are the top ~4-6 initiatives that your team will take on in H1 to help hit these goals?

</aside>

- 

<aside>
📖 Once you feel good about your set of projects, add them to the global [](../Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d.md) database below, tagging them to the objectives they’ll help drive.

</aside>

[Untitled](Growth%20H1%20Plan%201a485936ac6e810d94e8db40cfdd17ed/Untitled%201a485936ac6e8157b6a4d21ba8e66b92.csv)