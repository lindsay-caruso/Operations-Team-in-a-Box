# Notion Mid-Term Strategy

Type: Inputs
Owner: Esteban Balderas
Status: Finalized
👥 Team: Exec Team (../Teams%201a485936ac6e81838e99c43b6f2a8574/Exec%20Team%201a485936ac6e81499428dabb26a2adbb.md)

## What is the purpose of this strategy doc?

<aside>
🌟 The goal of this document is to outline Notion's product strategy through the second half of 2023.

</aside>

- Ensures that our work clearly moves us **towards our long-term mission of making software toolmaking ubiquitous**. The strategy should define a clear milestone for the product—and by extension the organization—that is a definitive step in the direction of that mission.
- **Aligns functions** on how they work together to achieve this milestone.
- Provides a high-level **framework** so that teams can **make decisions** independently—on optimization, prioritization and tradeoffs.
- Enables us to effectively, and accurately, **describe what our product will be** and not just what Notion currently is.

It's important to note that this document is not designed to answer every question. Instead, it provides a common direction and framework for decision making. More specifically, **it is not a product roadmap, company strategy, or goal setting exercise**.

## Background

Over the past couple of years, we’ve been pursuing two different goals:

- Developing a reliable and user-friendly software platform.
- Providing exceptional customer support and service to our users.

## Mid-term product strategy

<aside>
🎯 Our product objective is to pursue **customer-centric design** and **support**.

</aside>

The implementation of this strategy involves **three pillars, which we'll pursue simultaneously**. The detailed roadmaps for each of the pillars will be determined by the responsible teams, but you can expand the toggles below for an indicative (but not exhaustive or prescriptive) sense of what we might do for each.

### Customer research

Add more details in this toggle…

### Training & empowerment

Add more details in this toggle…

### Continuous improvement

Add more details in this toggle…

## What we are *not* going to do?

While the above says what we are going to do, it's almost as important to mention what we're not going to do**:**

- **Sacrificing quality for speed:** Avoid rushing to release new features or updates at the expense of quality, which can lead to a poor user experience and decreased customer satisfaction.2.
- **Ignoring customer feedback:** Don't disregard or dismiss customer feedback, as it can provide valuable insights into areas for improvement and help you stay ahead of the competition.
- **Focusing solely on short-term gains:** Avoid prioritizing short-term gains over long-term success, as this can lead to neglecting customer needs and sacrificing customer loyalty.

## What next?

There's a lot to do to make this vision a reality but we're confident that we can get there by the second half of next year. Over the next few weeks, the team will work on

- a staffing plan to determine how (and when) resourcing flows to each of these broad areas,
- area-specific strategies (when warranted, as for our platform work), and
- high-level product roadmaps so that we can have a rough sense of sequencing.