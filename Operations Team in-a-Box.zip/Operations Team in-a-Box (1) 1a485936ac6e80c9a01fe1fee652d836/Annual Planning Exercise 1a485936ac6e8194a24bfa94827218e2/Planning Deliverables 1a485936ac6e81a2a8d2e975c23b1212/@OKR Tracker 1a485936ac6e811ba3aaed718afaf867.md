# @OKR Tracker

Type: Company Plan
Owner: Holly Avery
Status: Finalized
👥 Team: Entire Company (../Teams%201a485936ac6e81838e99c43b6f2a8574/Entire%20Company%201a485936ac6e81a69ae1f3e0112121b1.md)