# Emerging Market Entry

Objectives: Enter emerging markets (../../OKR%20Tracker%201a485936ac6e8130956fdfdeda7b56b5/Enter%20emerging%20markets%201a485936ac6e81e8b155e26de354116a.md)
Status: Prioritized
Team: Sales (../Teams%201a485936ac6e81838e99c43b6f2a8574/Sales%201a485936ac6e811e944fe583376c793b.md)