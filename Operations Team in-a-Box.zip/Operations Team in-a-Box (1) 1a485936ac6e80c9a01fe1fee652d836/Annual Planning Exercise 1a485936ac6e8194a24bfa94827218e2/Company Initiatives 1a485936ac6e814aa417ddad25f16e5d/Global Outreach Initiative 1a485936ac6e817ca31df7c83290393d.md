# Global Outreach Initiative

Objectives: Enter emerging markets (../../OKR%20Tracker%201a485936ac6e8130956fdfdeda7b56b5/Enter%20emerging%20markets%201a485936ac6e81e8b155e26de354116a.md)
Status: Prioritized
Team: Growth (../Teams%201a485936ac6e81838e99c43b6f2a8574/Growth%201a485936ac6e8132a716f70c27841075.md)