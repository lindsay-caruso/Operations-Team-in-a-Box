# User-Centric Evolution

Objectives: Adapt products to needs (../../OKR%20Tracker%201a485936ac6e8130956fdfdeda7b56b5/Adapt%20products%20to%20needs%201a485936ac6e81bd92d0d26d1dc39aec.md)
Status: Discussion
Team: Core Product (../Teams%201a485936ac6e81838e99c43b6f2a8574/Core%20Product%201a485936ac6e818c88bece9083d976dd.md)