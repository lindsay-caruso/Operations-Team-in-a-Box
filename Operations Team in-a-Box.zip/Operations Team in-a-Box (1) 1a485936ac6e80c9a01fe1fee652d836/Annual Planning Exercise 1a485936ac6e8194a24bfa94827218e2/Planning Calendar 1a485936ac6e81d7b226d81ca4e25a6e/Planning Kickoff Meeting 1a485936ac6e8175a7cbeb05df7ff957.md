# Planning Kickoff Meeting

Type: Inputs
Date: December 15, 2022
Owner: Aki Tas
Status: Done
Who?: Entire company