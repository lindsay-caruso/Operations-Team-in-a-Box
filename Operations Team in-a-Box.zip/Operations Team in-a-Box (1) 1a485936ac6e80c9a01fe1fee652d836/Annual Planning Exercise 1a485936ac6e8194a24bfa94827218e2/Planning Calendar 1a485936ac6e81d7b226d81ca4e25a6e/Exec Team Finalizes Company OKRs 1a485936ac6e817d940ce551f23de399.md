# Exec Team Finalizes Company OKRs

Type: Goals
Date: January 2, 2023
Owner: Ivan Zhao
Status: Not started
Who?: Exec team