# Exec Team Offsite: Initial Guidance + Goals

Type: Inputs
Date: December 12, 2022 → December 14, 2022
Owner: Michael Manapat
Status: Done
Who?: Exec team