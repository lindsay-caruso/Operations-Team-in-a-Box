# Exec Team + Staff discussions/feedback

Type: Roadmaps
Date: January 10, 2023
Owner: Michael Manapat
Status: Not started
Who?: Exec team + division/org leads