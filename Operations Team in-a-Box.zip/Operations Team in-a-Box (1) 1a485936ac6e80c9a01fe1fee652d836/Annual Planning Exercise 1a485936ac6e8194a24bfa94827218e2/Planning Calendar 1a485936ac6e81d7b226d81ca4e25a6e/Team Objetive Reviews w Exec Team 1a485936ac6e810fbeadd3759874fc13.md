# Team Objetive Reviews w/ Exec Team

Type: Goals
Date: December 21, 2022 → December 23, 2022
Owner: Ivan Zhao
Status: Not started
Who?: Team leads + exec team