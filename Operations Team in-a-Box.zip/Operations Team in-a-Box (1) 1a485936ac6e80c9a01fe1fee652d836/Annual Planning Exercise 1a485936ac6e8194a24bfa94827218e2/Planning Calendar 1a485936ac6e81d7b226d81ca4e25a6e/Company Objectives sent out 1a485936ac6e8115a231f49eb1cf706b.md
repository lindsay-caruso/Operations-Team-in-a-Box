# Company Objectives sent out

Type: Goals
Date: January 3, 2023
Owner: Aki Tas
Status: Not started
Who?: Exec team