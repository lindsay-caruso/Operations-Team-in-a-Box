# Teams Write Plans

Type: Roadmaps
Date: January 4, 2023 → January 9, 2023
Owner: Matt Piccolella (Old)
Status: Not started
Who?: Entire company