# Teams Write Goals + OKRs

Type: Goals
Date: December 15, 2022 → December 20, 2022
Owner: Akshay Kothari
Status: In progress
Who?: Entire company