# Q1 Company Kickoff

Type: Wrap-Up
Date: January 17, 2023
Owner: Aki Tas
Status: Not started
Who?: Entire company