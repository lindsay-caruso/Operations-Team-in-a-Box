# Mid-Term Strategy Published

Type: Inputs
Date: December 14, 2022
Owner: Ivan Zhao
Status: Done
Who?: Exec team