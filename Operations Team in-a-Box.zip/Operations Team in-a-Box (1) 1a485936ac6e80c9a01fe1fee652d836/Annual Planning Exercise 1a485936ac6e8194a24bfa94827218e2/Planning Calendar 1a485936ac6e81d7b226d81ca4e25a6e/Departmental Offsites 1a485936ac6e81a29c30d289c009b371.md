# Departmental Offsites

Type: Inputs
Date: January 4, 2023 → January 9, 2023
Owner: Ivan Zhao
Status: Not started
Who?: Department + team leads