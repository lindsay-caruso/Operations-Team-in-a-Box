# Verification process in case of flag

Assignee: Matt Piccolella
Status: Done
Due: June 23, 2023
Project: Fraud detection and prevention model (../Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1/Fraud%20detection%20and%20prevention%20model%201a485936ac6e8124a21cc57494f9a31f.md)
Priority: High

## Description

-