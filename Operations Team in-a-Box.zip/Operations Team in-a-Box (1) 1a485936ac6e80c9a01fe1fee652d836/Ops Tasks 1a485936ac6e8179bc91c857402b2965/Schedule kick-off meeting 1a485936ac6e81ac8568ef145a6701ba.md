# Schedule kick-off meeting

Assignee: Harold Jackson
Status: In Progress
Due: June 17, 2023
Project: Order fulfillment optimization (../Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1/Order%20fulfillment%20optimization%201a485936ac6e81688e4dc6117d02a5c0.md)
Priority: Medium

- Goals:
    - Schedule kick-off meeting for the performance project
    - Prep meeting materials in advance
    - Meeting goal is to review the project proposal
- Non-goals:
    - Brainstorm additional performance projects
- Next steps:
    - Invite all stakeholders to the meeting
    - Prepare meeting agenda