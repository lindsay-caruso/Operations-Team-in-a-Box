# Review research results

Assignee: Sohrab Amin
Status: Not Started
Due: July 1, 2023
Project: Advanced inventory tracking (../Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1/Advanced%20inventory%20tracking%201a485936ac6e813dbc03c1f771540690.md)
Priority: Medium
Tags: Website

- Goals:
    - Understand which product areas need most education
    - Deprioritize product areas that already see high engagement
- Non-goals:
    - Recommend UI changes for core product
    - Recommend changes to product roadmap
- Next steps:
    - Watch all 10 interviews from research team
    - Write up insights and share in Slack