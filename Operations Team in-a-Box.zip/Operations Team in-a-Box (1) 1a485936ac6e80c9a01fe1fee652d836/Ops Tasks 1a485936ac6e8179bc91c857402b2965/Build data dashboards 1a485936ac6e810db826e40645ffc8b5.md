# Build data dashboards

Assignee: Zoe
Status: Not Started
Due: June 20, 2023
Project: Advanced inventory tracking (../Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1/Advanced%20inventory%20tracking%201a485936ac6e813dbc03c1f771540690.md)
Priority: Medium
Tags: Website

- Goals:
    - Give cross-functional partners the ability to self serve info about tooltip effectiveness among new user cohorts
    - Measure activation and retention against control group
- Non-goals:
    - Add new events to track new feature adoption
    - Track how often tooltips are skipped (blocked for now)
- Next steps:
    - Ask Jonny for access to Hex
    - Schedule cross-functional meeting to collect any remaining feedback and requests