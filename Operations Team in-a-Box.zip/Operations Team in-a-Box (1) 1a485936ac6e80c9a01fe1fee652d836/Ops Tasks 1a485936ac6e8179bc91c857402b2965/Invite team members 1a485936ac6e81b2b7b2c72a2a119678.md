# Invite team members

Assignee: Matt Piccolella
Status: Not Started
Due: July 14, 2023
Project: Scalability Q2 Initiative (../Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1/Scalability%20Q2%20Initiative%201a485936ac6e812b974cfab054d850d4.md)
Priority: High

- Ready to collaborate with your team? Use the Share menu at the top right.
- Use the “Assignee” field above to assign tasks to your teammates. They’ll see a notification in their sidebar.