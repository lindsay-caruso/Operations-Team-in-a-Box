# Add a new task

Assignee: Andrea Lim
Status: Not Started
Due: June 22, 2023
Project: Scalability Q2 Initiative (../Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1/Scalability%20Q2%20Initiative%201a485936ac6e812b974cfab054d850d4.md)
Priority: High

- Ready to start tracking your tasks here? Start by clicking the blue “New” button at the top right of your table.
- Customize each task by populating the fields above, such as the task’s assignee, due date, and status.