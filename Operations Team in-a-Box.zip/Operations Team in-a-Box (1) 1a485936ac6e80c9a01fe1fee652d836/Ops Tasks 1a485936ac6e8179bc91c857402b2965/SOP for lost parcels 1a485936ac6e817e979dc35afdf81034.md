# SOP for lost parcels

Assignee: Andrea Lim
Status: Done
Project: Integrate with new shipping partner (../Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1/Integrate%20with%20new%20shipping%20partner%201a485936ac6e818fbb30ead725cbc800.md)
Priority: High

## Description

-