# Agree on top 4 currencies to support

Assignee: Zoe
Status: In Progress
Project: Payment gateway for LATAM (../Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1/Payment%20gateway%20for%20LATAM%201a485936ac6e814997b5de5e23a05e0c.md)
Priority: Medium