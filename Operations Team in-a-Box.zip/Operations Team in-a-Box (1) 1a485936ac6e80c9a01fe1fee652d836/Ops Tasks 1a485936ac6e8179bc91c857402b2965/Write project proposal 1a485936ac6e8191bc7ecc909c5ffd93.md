# Write project proposal

Assignee: Sohrab Amin
Status: Done
Due: June 19, 2023
Project: Order fulfillment optimization (../Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1/Order%20fulfillment%20optimization%201a485936ac6e81688e4dc6117d02a5c0.md)
Priority: Low
Tags: Improvement

- Goals:
    - Achieve cross-functional alignment on why and how we’re investing in mobile performance in Q3
    - Include more user stories, specific problem statements, and be crisp about what’s not in scope for now
- Non-goals:
    - Get explicit leadership sign-off
    - Synthesize user research learnings (already captured in research team’s performance doc)
- Next steps:
    - Gather feedback from mobile team
    - Work with internal comms to create awareness in the appropriate Slack channels