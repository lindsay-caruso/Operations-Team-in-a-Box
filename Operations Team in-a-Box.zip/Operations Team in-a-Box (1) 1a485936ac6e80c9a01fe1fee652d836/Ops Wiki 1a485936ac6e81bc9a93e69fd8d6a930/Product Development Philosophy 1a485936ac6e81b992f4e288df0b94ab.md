# Product Development Philosophy

<aside>
💡 **Notion Tip:** Add more details right in this page, including toggles, images, and more. Break up the page by using our different header options so that it’s easier to read. Learn more about different types of content blocks [here](https://www.notion.so/guides/types-of-content-blocks).

</aside>