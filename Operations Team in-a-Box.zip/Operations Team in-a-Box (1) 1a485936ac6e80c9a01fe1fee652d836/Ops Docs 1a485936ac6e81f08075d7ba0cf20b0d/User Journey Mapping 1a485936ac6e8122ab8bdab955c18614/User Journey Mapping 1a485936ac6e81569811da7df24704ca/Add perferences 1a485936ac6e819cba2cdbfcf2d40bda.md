# Add perferences

Type: Action
Phase: Onboarding