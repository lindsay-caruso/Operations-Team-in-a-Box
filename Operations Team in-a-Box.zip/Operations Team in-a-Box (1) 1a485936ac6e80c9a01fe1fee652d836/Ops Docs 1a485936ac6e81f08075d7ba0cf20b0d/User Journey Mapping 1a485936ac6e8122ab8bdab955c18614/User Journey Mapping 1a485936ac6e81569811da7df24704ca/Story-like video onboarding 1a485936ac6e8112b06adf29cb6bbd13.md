# Story-like video onboarding

Type: Opportunities
Phase: Onboarding