# Connect Twitter Account

Type: Action
Phase: Register