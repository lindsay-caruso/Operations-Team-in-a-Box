# Walkthrough video

Type: Action
Phase: Onboarding