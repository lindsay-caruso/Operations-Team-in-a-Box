# Create first workspace

Type: Action
Phase: Activation