# Enable email notifications

Type: Action
Phase: Onboarding