# Short attention spans / churn

Type: Painpoint
Phase: Activation