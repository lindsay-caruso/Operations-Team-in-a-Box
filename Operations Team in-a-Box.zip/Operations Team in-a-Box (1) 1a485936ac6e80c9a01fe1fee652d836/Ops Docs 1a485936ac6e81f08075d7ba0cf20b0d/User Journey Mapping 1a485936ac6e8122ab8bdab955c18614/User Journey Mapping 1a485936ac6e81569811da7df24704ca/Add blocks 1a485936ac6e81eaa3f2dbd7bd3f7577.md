# Add blocks

Type: Action
Phase: Activation