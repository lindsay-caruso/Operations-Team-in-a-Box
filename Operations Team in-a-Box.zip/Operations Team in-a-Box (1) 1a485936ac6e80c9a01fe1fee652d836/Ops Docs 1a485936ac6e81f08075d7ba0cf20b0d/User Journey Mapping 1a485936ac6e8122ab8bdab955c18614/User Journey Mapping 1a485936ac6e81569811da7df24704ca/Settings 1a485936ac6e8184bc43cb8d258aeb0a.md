# Settings

Type: Touchpoint
Phase: Onboarding