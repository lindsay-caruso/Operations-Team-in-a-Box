# Initial recommendations in dashboard

Type: Opportunities
Phase: Register