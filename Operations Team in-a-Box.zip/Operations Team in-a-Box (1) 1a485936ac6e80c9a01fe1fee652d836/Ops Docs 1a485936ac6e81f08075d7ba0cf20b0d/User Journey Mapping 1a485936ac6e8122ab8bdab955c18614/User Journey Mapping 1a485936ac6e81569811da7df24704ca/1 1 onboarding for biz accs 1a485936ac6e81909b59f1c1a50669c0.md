# 1:1 onboarding for biz accs

Type: Opportunities
Phase: Onboarding