# Complete profile

Type: Action
Phase: Onboarding