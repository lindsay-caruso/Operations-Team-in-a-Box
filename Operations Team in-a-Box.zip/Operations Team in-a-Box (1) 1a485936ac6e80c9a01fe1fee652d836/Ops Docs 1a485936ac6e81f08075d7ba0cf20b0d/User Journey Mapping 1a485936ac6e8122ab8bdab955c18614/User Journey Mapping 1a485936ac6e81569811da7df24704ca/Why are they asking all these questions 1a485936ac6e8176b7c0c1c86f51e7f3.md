# Why are they asking all these questions?

Type: Emotion
Phase: Activation