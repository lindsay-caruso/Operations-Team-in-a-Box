# Ask for permissions only when needed

Type: Opportunities
Phase: Activation