# Short attention spans / churn

Type: Painpoint
Phase: Onboarding