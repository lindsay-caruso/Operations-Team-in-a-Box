# Too many options to pick from. Paralysis by analysis

Type: Painpoint
Phase: Register