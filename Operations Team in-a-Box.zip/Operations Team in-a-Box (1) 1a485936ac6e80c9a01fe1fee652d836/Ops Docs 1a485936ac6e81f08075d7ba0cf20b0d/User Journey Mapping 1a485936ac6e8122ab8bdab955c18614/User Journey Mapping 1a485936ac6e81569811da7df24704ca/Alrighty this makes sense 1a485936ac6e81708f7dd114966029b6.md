# Alrighty this makes sense

Type: Emotion
Phase: Onboarding