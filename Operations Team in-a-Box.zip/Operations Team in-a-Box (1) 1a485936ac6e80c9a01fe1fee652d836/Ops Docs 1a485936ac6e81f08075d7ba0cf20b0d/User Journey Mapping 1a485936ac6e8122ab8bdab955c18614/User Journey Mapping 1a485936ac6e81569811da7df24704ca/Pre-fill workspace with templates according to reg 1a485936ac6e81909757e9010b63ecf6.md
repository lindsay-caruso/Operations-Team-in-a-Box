# Pre-fill workspace with templates according to registration inputs

Type: Opportunities
Phase: Register