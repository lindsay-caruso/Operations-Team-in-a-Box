# This is taking too long

Type: Emotion
Phase: Activation