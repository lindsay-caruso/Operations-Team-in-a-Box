# What are all these blocks?

Type: Emotion
Phase: Register