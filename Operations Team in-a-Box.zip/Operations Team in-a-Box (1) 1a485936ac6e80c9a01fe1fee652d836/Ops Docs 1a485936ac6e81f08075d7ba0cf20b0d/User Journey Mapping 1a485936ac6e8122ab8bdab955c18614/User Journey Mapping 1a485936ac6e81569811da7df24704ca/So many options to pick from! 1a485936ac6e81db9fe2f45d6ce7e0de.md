# So many options to pick from!

Type: Emotion
Phase: Register