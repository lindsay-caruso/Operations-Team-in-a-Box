# Free Resources

Type: Touchpoint
Phase: Activation