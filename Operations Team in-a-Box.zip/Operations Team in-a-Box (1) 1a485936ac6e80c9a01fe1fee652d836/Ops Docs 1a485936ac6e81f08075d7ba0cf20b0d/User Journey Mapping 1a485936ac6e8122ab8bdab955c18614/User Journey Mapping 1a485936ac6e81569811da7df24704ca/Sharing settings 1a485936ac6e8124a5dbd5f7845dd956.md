# Sharing settings

Type: Touchpoint
Phase: Register