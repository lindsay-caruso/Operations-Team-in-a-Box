# Give permissions

Type: Action
Phase: Register