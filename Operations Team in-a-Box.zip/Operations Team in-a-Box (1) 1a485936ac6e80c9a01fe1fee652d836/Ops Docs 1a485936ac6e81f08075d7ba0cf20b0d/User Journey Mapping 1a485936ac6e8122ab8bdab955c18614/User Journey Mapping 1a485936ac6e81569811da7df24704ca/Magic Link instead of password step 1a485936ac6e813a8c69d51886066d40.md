# Magic Link instead of password step

Type: Opportunities
Phase: Activation