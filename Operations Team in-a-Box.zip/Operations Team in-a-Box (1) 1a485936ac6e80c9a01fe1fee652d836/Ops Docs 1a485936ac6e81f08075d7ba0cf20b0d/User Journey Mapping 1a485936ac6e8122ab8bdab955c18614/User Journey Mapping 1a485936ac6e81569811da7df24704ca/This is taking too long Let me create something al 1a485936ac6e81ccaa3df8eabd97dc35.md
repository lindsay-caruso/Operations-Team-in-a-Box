# This is taking too long. Let me create something already!

Type: Emotion
Phase: Onboarding