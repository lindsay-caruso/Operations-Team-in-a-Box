# SOP / Approve Seller

Type: SOP

<aside>
💡 A standard operating procedure (SOP) is a set of step-by-step instructions compiled by an organization to help workers carry out routine operations. SOPs aim to achieve efficiency, quality output, and uniformity of performance, while reducing miscommunication and failure to comply with industry regulations.

</aside>

# Document Purpose

What is this document for?

---

# Document Scope

What is the scenario which this SOP is applicable?

---

# Definitions and Acronyms

| **Term or Acronym** | **Definition or Meaning** |
| --- | --- |
| Insert your term here | So that the reader understands the term or acronym. |
|  |  |

---

# The Process Steps

[https://miro.com/app/board/uXjVM-chCUk=/?share_link_id=977546363789](https://miro.com/app/board/uXjVM-chCUk=/?share_link_id=977546363789)

# Related Resources

-