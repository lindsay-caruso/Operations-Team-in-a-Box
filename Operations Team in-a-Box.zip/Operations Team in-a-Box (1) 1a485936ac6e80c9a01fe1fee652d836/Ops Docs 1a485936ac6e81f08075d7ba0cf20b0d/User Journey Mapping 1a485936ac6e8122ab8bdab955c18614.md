# User Journey Mapping

Type: Analysis
Author: Nate Martins

[User Journey Mapping](User%20Journey%20Mapping%201a485936ac6e8122ab8bdab955c18614/User%20Journey%20Mapping%201a485936ac6e81569811da7df24704ca.csv)

## MIRO

---

[https://miro.com/app/board/uXjVM-Yhwck=/?share_link_id=139645432017](https://miro.com/app/board/uXjVM-Yhwck=/?share_link_id=139645432017)

### FIGJAM

---

[https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FgorHXA8yirfCy5IUOX0acb%2FUser-journey-map-(Community)%3Ftype%3Dwhiteboard%26node-id%3D0%3A1%26t%3DXbRVMWIAdHMxxUxA-1](https://www.figma.com/embed?embed_host=notion&url=https%3A%2F%2Fwww.figma.com%2Ffile%2FgorHXA8yirfCy5IUOX0acb%2FUser-journey-map-(Community)%3Ftype%3Dwhiteboard%26node-id%3D0%3A1%26t%3DXbRVMWIAdHMxxUxA-1)