# Launch do-it-yourself flow by Q4

Owner: Matt Piccolella
Objective: Adapt products to needs (Adapt%20products%20to%20needs%201a485936ac6e81bd92d0d26d1dc39aec.md)
Status: 🟢
Target Date: September 1, 2023