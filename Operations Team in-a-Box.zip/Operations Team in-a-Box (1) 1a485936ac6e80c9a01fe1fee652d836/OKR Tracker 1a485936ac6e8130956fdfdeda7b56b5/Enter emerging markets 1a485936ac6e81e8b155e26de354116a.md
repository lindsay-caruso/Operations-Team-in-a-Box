# Enter emerging markets

Owner: Ivan Zhao
Key Results: Hire Regional Head of Sales / Africa (Hire%20Regional%20Head%20of%20Sales%20Africa%201a485936ac6e817eb180e79edc010965.md), 200k MAU in emerging markets by EOY (200k%20MAU%20in%20emerging%20markets%20by%20EOY%201a485936ac6e818aa250d9d59058ccfb.md), Localise website to 4 core languages by Q3 (Localise%20website%20to%204%20core%20languages%20by%20Q3%201a485936ac6e81be967ed0af431801e7.md)
Status: 🟢
Team Initiatives: Global Outreach Initiative (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Global%20Outreach%20Initiative%201a485936ac6e817ca31df7c83290393d.md), Emerging Market Entry (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Emerging%20Market%20Entry%201a485936ac6e81bb9718c1bfe05c61f6.md)