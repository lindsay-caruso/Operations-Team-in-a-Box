# Implement API integrations

Owner: Virginia Conde
Key Results: Expose 22 core endpoints by Q2 (Expose%2022%20core%20endpoints%20by%20Q2%201a485936ac6e8139b688da73e2123b09.md)
Status: 🟠
Team Initiatives: API Integration Suite (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/API%20Integration%20Suite%201a485936ac6e816499e8cc14496443c5.md), Cross-Platform Connector (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Cross-Platform%20Connector%201a485936ac6e81fc8e52f1f8884b7586.md)