# Forge strategic partnerships

Owner: Michael Manapat
Key Results: Dsitribution agreement with SuperCorp by Q3 (Dsitribution%20agreement%20with%20SuperCorp%20by%20Q3%201a485936ac6e813b9048f14cc5eb8957.md)
Status: 🟢
Team Initiatives: Partner Alliance Initiative (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Partner%20Alliance%20Initiative%201a485936ac6e816ba038ff4bc03a8b3b.md), Collaborative Growth Program (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Collaborative%20Growth%20Program%201a485936ac6e8145a5b5fa4957fe8974.md), Tech Alliance Network (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Tech%20Alliance%20Network%201a485936ac6e812e9a87f0b1cb4c76d4.md)