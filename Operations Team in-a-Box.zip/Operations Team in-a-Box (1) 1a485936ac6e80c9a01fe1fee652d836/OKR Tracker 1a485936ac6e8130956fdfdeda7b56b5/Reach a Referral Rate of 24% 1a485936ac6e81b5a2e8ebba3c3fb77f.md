# Reach a Referral Rate of 24%

Owner: Seo Kyung Kim
Objective: Loyalty program (Loyalty%20program%201a485936ac6e814b8aabe68bb83239ef.md)
Status: 🔴
Target Date: June 1, 2023