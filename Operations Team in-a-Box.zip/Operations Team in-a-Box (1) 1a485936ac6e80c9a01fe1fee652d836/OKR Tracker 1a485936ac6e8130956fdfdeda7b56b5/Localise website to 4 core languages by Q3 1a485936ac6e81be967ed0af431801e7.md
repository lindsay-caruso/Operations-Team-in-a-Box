# Localise website to 4 core languages by Q3

Owner: Andrea Lim
Objective: Enter emerging markets (Enter%20emerging%20markets%201a485936ac6e81e8b155e26de354116a.md)
Status: 🟢
Target Date: March 1, 2023