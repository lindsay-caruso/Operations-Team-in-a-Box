# 200k MAU in emerging markets by EOY

Owner: Ben Lang
Objective: Enter emerging markets (Enter%20emerging%20markets%201a485936ac6e81e8b155e26de354116a.md)
Status: 🟠
Target Date: June 1, 2023