# Loyalty program

Owner: Sohrab Amin
Key Results: Reach a Referral Rate of 24% (Reach%20a%20Referral%20Rate%20of%2024%25%201a485936ac6e81b5a2e8ebba3c3fb77f.md)
Status: 🔴
Team Initiatives: Customer Loyalty Rewards (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Customer%20Loyalty%20Rewards%201a485936ac6e817b880ceacc49a0f49c.md), Engage & Retain Program (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Engage%20&%20Retain%20Program%201a485936ac6e812fae9cdc58e33958a8.md)