# Expose 22 core endpoints by Q2

Owner: Nate Martins
Objective: Implement API integrations (Implement%20API%20integrations%201a485936ac6e8149b96ee84f081e9560.md)
Status: 🟠
Target Date: February 1, 2023