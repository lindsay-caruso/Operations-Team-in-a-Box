# Reduce time to reach agent to under a minute

Owner: Sohrab Amin
Objective: Enhance support channels (Enhance%20support%20channels%201a485936ac6e81239952fbbbe1e8c42d.md)
Status: 🟢
Target Date: March 1, 2023