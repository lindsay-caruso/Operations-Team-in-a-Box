# Increase Support Satisfaction Score to 93%

Owner: Matt Piccolella
Objective: Enhance support channels (Enhance%20support%20channels%201a485936ac6e81239952fbbbe1e8c42d.md)
Status: 🟠
Target Date: June 1, 2023