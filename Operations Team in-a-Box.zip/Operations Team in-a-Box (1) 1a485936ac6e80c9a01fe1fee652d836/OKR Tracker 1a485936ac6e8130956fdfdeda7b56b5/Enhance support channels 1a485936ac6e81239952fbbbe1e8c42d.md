# Enhance support channels

Owner: Sohrab Amin
Key Results: Reduce time to reach agent to under a minute (Reduce%20time%20to%20reach%20agent%20to%20under%20a%20minute%201a485936ac6e810c9928f129fa71893a.md), Increase Support Satisfaction Score to 93% (Increase%20Support%20Satisfaction%20Score%20to%2093%25%201a485936ac6e819e9decdb7f359e46b4.md)
Status: 🟠
Team Initiatives: Customer Care Enhancement (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Customer%20Care%20Enhancement%201a485936ac6e818c8386d32281004695.md), Omni-Channel Assistance (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Omni-Channel%20Assistance%201a485936ac6e81ba89e3e0d8ab5b0e79.md)