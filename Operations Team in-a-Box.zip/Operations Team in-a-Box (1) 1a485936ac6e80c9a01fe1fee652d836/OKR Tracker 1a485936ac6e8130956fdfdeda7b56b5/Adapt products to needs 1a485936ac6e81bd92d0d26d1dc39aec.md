# Adapt products to needs

Owner: Andrea Lim
Key Results: Launch do-it-yourself flow by Q4 (Launch%20do-it-yourself%20flow%20by%20Q4%201a485936ac6e817ca8dcd5f62d49a37f.md)
Status: 🟢
Team Initiatives: Tailored Solutions Development (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/Tailored%20Solutions%20Development%201a485936ac6e81668163c4308cd52e60.md), User-Centric Evolution (../Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2/Company%20Initiatives%201a485936ac6e814aa417ddad25f16e5d/User-Centric%20Evolution%201a485936ac6e81dd86ffcd5ec74a5985.md)