# Operations Team in-a-Box (1)

- **Notion Tip:** Use this template to streamline product development, gather all your resources under one roof and create a collaborative environment for your team.
    
    The template includes:
    
    - **Annual Planning Exercise →** An extensive document that helps you execute and organize the outcomes of your annual planning.
    - **OKR Tracker →** A neat way to organize your objectives and their key results, track progress and updates. A simpler version is also available: [**Simple Company Goals →**](Operations%20Team%20in-a-Box%20(1)%201a485936ac6e80c9a01fe1fee652d836/Ops%20Docs%201a485936ac6e81f08075d7ba0cf20b0d/Simple%20Company%20Goals%201a485936ac6e81d2b640eedbf9c6706d.md)
    - **Vendor Management →** Directors of vendors, contact points, contracts, SLAs and evaluation reports.
    - **Ops Projects →** Plan, prioritise and monitor projects from the backlog to realisation.
    - **Ops Tasks →**  Break down projects to smaller more managable pieces.
    - **Ops Wiki →** resources to help be a member of the team.
    - **Ops Meetings →** all your meeting notes and actions under one roof. Also includes templates for:
        - Board meetings
        - Post-mortems
        - Business Reviews
    - **Ops Docs →** contains all your team’s documents. Also includes a template for:
        - SOPs: Document your standard operating procedures.

<aside>
<img src="https://www.notion.so/icons/token_green.svg" alt="https://www.notion.so/icons/token_green.svg" width="40px" /> **Team Vision:** Setup streamlined and agile operations through automation and strategic partnerships.

</aside>

<aside>
<img src="https://www.notion.so/icons/flag_green.svg" alt="https://www.notion.so/icons/flag_green.svg" width="40px" /> **Team Mission:** Optimize operations for efficient and reliable delivery of tech solutions.

</aside>

# Team

|  | Type | Function / Role |
| --- | --- | --- |
| @Monica Perez  | Core Team | Head of Operations |
| @Matt Piccolella | Core Team | Marketplace Optimization |
| @Emily Fernandez  | Core Team | Offline Ops |
| @Harold Jackson  | Core Team | Customer Support Manager |
| @Esteban Balderas  | Collaborator | Data Analytics |
| @Maria Caprani  | Collaborator | Product Manager |

# Goals

### 🍵 Shed operational expenses

Reduce operational expenses by 15% compared to the previous year.

### 🛠️ Reduce average response time

Streamline workflows and implement automation to decrease the average response time for operational requests by 20%.

### 🌳 System scalability boost

Implement infrastructure upgrades and optimize systems to ensure seamless scalability and support our projected growth to 1M MAU.

# **Internal team links**

[Ops Projects](Operations%20Team%20in-a-Box%20(1)%201a485936ac6e80c9a01fe1fee652d836/Ops%20Projects%201a485936ac6e8190bf71df1ec86216d1.csv)

[Ops Tasks](Operations%20Team%20in-a-Box%20(1)%201a485936ac6e80c9a01fe1fee652d836/Ops%20Tasks%201a485936ac6e8179bc91c857402b2965.csv)

[OKR Tracker](Operations%20Team%20in-a-Box%20(1)%201a485936ac6e80c9a01fe1fee652d836/OKR%20Tracker%201a485936ac6e8130956fdfdeda7b56b5.csv)

[Ops Docs](Operations%20Team%20in-a-Box%20(1)%201a485936ac6e80c9a01fe1fee652d836/Ops%20Docs%201a485936ac6e81f08075d7ba0cf20b0d.csv)

[Ops Meetings](Operations%20Team%20in-a-Box%20(1)%201a485936ac6e80c9a01fe1fee652d836/Ops%20Meetings%201a485936ac6e8104a426f85dd2bb5d45.csv)

[Ops Wiki](Operations%20Team%20in-a-Box%20(1)%201a485936ac6e80c9a01fe1fee652d836/Ops%20Wiki%201a485936ac6e81bc9a93e69fd8d6a930.md)

# **External company links**

[Vendor Management](Operations%20Team%20in-a-Box%20(1)%201a485936ac6e80c9a01fe1fee652d836/Vendor%20Management%201a485936ac6e81f5860cf0e9846bce5d.csv)

[Annual Planning Exercise](Operations%20Team%20in-a-Box%20(1)%201a485936ac6e80c9a01fe1fee652d836/Annual%20Planning%20Exercise%201a485936ac6e8194a24bfa94827218e2.md)

#